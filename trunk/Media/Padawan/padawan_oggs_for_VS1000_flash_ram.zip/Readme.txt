
These OGG's were encoded from the MP3's found in the Padawan zip file.
They have been renamed with leading zeroes and in uppercase 8.3 format.
Long sounds (9Theme,10Cantina,11Emperor,12Chorus) have been cut down to much
shorter clips to allow all of these files to fit on the internal memory of
a VS1000 Audio Module.
All sounds have been downmixed to mono.
Most files have an average bitrate of 32kbps.

Paul Murphy (joymonkey@gmail.com)
6/18/13