#ifndef __CREDENTIALS_H__
#define __CREDENTIALS_H__

// Wifi parameters
char passphrase[] = "YourSecretPassPhrase123";
char ssid[] = "YourSSID";
char ntp_server[] = "nist1-la.ustiming.org"; // or your favorite ntp server.

#endif
